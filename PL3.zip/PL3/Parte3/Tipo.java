public enum Tipo {
    INT,      // Entero
    FLOAT,    // Coma flotante
    STRING,   // Cadena de texto
    BOOL,     // Booleano (0/1)
    DESCONOCIDO
}
